mv ~/Control/RyuController/nfv_controller.py /tmp/ryu/ryu/app/
mv ~/Control/RyuController/nfv.config /tmp/ryu/ryu/app/
